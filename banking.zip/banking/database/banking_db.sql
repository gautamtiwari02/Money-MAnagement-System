-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2022 at 08:56 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banking_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(30) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `pin` text NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `middlename` varchar(250) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `generated_password` text NOT NULL,
  `balance` float NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `account_number`, `pin`, `firstname`, `lastname`, `middlename`, `email`, `password`, `generated_password`, `balance`, `date_created`, `date_updated`) VALUES
(2, '0001', '6231415', 'Min', 'Bhattrai', 'parsad', '0001', '', '0001', 458140, '2021-07-14 12:05:19', '2022-06-03 13:06:54'),
(4, '0010', '0010', 'Gautam', 'Tiwari', '', '0010', '', '0010', 7578, '2022-05-19 10:44:16', '2022-06-03 13:00:07'),
(5, '0011', '0011', 'Hari', 'poudel', 'parsad', '0011', '', '0011', 10000, '2022-05-19 10:45:08', '2022-06-05 08:30:54'),
(6, '1000', '1000', 'Ashok', 'Gyawali', '', '1000', '', '1000', 13378, '2022-05-19 13:15:29', '2022-06-03 12:42:32'),
(7, '1001', '1001', 'Ganesh ', 'Gaire', '', '1001', '', '1001', 4460, '2022-05-19 13:19:04', NULL),
(8, '0110', '0110', 'Ram', 'dubey', 'parsad', '0110', '', '0110', 8000, '2022-05-19 13:31:01', '2022-05-19 13:50:54'),
(9, '0111', '0111', 'Rohit', 'Shrestha', '', '0111', '', '0111', 5776, '2022-05-20 11:03:45', '2022-06-03 12:14:19'),
(10, 'abc', '1111', 'ganesh', 'poudel', 'prasad', '1111', '', '1111', 3236, '2022-05-20 14:21:11', '2022-06-03 12:35:22');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(30) NOT NULL,
  `title` text NOT NULL,
  `announcement` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `announcement`, `date_created`, `date_updated`) VALUES
(1, 'System Update', 'Our organization is going to update the system. Now user can see their transaction history.', '2021-07-14 14:10:09', '2022-05-19 13:03:02');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Money Management System'),
(6, 'short_name', 'MMSC-O'),
(11, 'logo', 'uploads/1652941920_1626243720_bank.jpg'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/1652941920_iStock-1130326185.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(30) NOT NULL,
  `account_id` int(30) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1=Cash in, 2= Withdraw, 3=transfer',
  `amount` float NOT NULL,
  `remarks` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `month` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `account_id`, `type`, `amount`, `remarks`, `date_created`, `month`) VALUES
(7, 1, 1, 5000, 'acd', '2022-06-03 11:58:44', 'jestha'),
(18, 4, 1, 1000, 'Beginning balance', '2022-05-19 10:44:16', ''),
(19, 5, 1, 3000, 'Beginning balance', '2022-05-19 10:45:08', ''),
(23, 6, 1, 5000, 'Beginning balance', '2022-05-19 13:15:29', ''),
(24, 7, 1, 4460, 'Beginning balance', '2022-05-19 13:19:04', ''),
(25, 8, 1, 5000, 'Beginning balance', '2022-05-19 13:31:01', ''),
(41, 9, 1, 500, 'Withdraw', '2022-05-20 11:05:06', ''),
(42, 5, 1, 2000, 'Deposits', '2022-05-20 12:43:51', ''),
(49, 9, 1, 500, 'Withdraw', '2022-06-03 11:47:13', ''),
(50, 6, 1, 1500, 'Deposits', '2022-06-03 11:47:29', ''),
(53, 9, 1, 200, 'Deposits', '2022-06-03 12:09:57', 'sharawan'),
(54, 9, 1, 4576, 'Deposits', '2022-06-03 12:14:19', ''),
(55, 10, 1, 1236, 'Deposits', '2022-06-03 12:35:22', 'aaitabar'),
(56, 6, 1, 5678, 'Deposits', '2022-06-03 12:42:32', ''),
(57, 4, 1, 6578, 'Deposits', '2022-06-03 13:00:07', 'sharawan'),
(58, 2, 1, 454564, 'Deposits', '2022-06-03 13:05:40', ''),
(59, 2, 1, 76, 'Deposits', '2022-06-03 13:06:54', 'jesrha'),
(60, 5, 1, 5000, 'Deposits', '2022-06-05 08:30:54', 'kartik');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/1624240500_avatar.png', NULL, 1, '2021-01-20 14:02:37', '2021-06-21 09:55:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
